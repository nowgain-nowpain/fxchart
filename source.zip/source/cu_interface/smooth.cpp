
//
// NOTE: 
//this smooth algorithm does not support volumes with null values!
// to support null values (skip voxels with nulls or nans), need
// another assistance working vol to store the weight (# of voxels
// averaged). It is init to 1 for all non null/nan voxels, 0 for
// all null/nan voxels). 
//
#include <smoothfilter.h>

//ZCH: After refactored this function out as a separate .cpp and move the related 
// two functions: smooth_pined_memory and smooth_pageable_memory to smoothfilter.h
// and add extern and DLL EXPORTs, also add extern for average, smooth_pined_memory, in
// the .cu file . Now it compiles and run OK. 
// before this refactor, the compiler complains about can't find test_smooth in
// the test_smooth_vol.cpp, though the function is defined at the top of it. 
// this is really weird; But when comment out the call to this average function
// in the test_smooth() function, it compiles without complain!

// canot find this header on Linux!
//#include <cuda_profiler_api.h>

#define USE_PINED_MEMORY  1
extern "C"
void average(float* outGrid,
       float const* inGrid,
       int halfx, // half windows size in X direction.
       int halfy, // half windows size in Y direction.
       int halfz, // half windows size in Z direction.
       int numX, // number of cells in X direction.
       int numY, // number of cells in Y direction.
       int numZ, // number of cells in Z direction.
       int blockX, 
       int blockY,
       int blockZ
) {


   size_t size = numX * numY * numZ;
   size_t sizeInBytes = size*sizeof(float);

//   cudaProfilerStart();

#if USE_PINED_MEMORY    
   smooth_pined_memory(outGrid, const_cast<float*>(inGrid), sizeInBytes,
      numX, numY, numZ,
      halfx, halfy, halfz,
      blockX, blockY, blockZ );

#else
   smooth_pageable_memory(outGrid, const_cast<float*>(inGrid), sizeInBytes,
      numX, numY, numZ,
      halfx, halfy, halfz,
      blockX, blockY, blockZ );

#endif

 //  cudaProfilerStop();
}

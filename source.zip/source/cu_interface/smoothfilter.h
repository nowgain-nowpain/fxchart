#ifndef _AVERAGE_FILTER_H_
#define _AVERAGE_FILTER_H_

#include "export_import.h"

#include <stdlib.h>

extern "C" 
{

CU_INTERFACE_EXPORT void average(float* outGrid,
    float const* inGrid,
    int halfx, // half windows size in X direction.
    int halfy, // half windows size in Y direction.
    int halfz, // half windows size in Z direction.
    int numX, // number of cells in X direction.
    int numY, // number of cells in Y direction.
    int numZ, // number of cells in Z direction.
    int blockX,
    int blockY,
    int blockZ
); 

CU_INTERFACE_EXPORT  void smooth_pined_memory(
	float* h_outGrid, float const* h_inGrid,
	size_t sizeInBytes,
	int numX, int numY, int numZ,
	int halfx, int halfy, int halfz,
	int blockX, int blockY, int blockZ
);

CU_INTERFACE_EXPORT void smooth_pageable_memory(
	float* h_out, float const* h_in,
	size_t sizeInBytes,
	int numX, int numY, int numZ,
	int halfx, int halfy, int halfz,
	int blockX, int blockY, int blockZ
);

}
#endif

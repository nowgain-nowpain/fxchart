#ifndef  _ZPKG_INTERPOLATE_H_
#define  _ZPKG_INTERPOLATE_H_

#include "export_import.h"

#include <volume.h>


extern "C" {

	// interpMethod 0 = nearest point;
	// interpMethod 1 = triliear;
	CU_INTERFACE_EXPORT void interpolate(ZPKG::volume* outGrid, ZPKG::volume const* inGrid, int blockX, int blockY, int blockZ, int interpMethod);

	CU_INTERFACE_EXPORT void interpNearPoint(ZPKG::volume* outGrid, ZPKG::volume const* inGrid, int blockX, int blockY, int blockZ);

	CU_INTERFACE_EXPORT void interpTrilinear(ZPKG::volume* outGrid, ZPKG::volume const* inGrid, int blockX, int blockY, int blockZ);
}

#endif

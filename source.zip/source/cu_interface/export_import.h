#pragma once
 
#ifndef CU_INTERFACE_EXPORT_H
#define CU_INTERFACE_EXPORT_H

#if defined(_WIN32)
#	if defined(CU_INTERFACE_STATIC)
#		define CU_INTERFACE_EXPORT
#	else
#		if defined(CU_INTERFACE_EXPORTS)
#			define CU_INTERFACE_EXPORT __declspec(dllexport)
#		else
#			define CU_INTERFACE_EXPORT __declspec(dllimport)
#		endif
#	endif
#else
#   define CU_INTERFACE_EXPORT
#endif

#endif  //CU_INTERFACE_EXPORT_H
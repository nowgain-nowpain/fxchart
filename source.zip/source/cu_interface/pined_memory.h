#ifndef _PINED_MEMORY_TEST_
#define _PINED_MEMORY_TEST_


#include "export_import.h"

extern "C"
CU_INTERFACE_EXPORT void pageable_memory_transfer(const unsigned int bytes, unsigned int nElements);

extern "C"
CU_INTERFACE_EXPORT void pined_memory_transfer(const unsigned int bytes, unsigned int nElements);

#endif

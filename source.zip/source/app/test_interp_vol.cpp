
#include "interpolate.h"
#include "volume.h"

#include <iostream>
#include <fstream>
#include <iomanip> 

#include <vector>
#include <tuple>
#include <iterator>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <chrono>

//#define VERBOSE  0

int test(int nxIn, int nyIn, int nzIn, 
     int nxOut, int nyOut, int nzOut,
     int blockX, int blockY, int blockZ,
    bool timing=false, int interp_method = 0) 
{
    const size_t totalItems = nxIn*nyIn*nzIn;
    ZPKG::volume inGrid(nxIn, nyIn, nzIn); // input
    ZPKG::volume gpuOutGrid(nxOut, nyOut, nzOut);  // output
    ZPKG::volume cpuOutGrid(nxOut, nyOut, nzOut);  // output

    ZPKG::volume::fill_input_grid(inGrid, 0);

    // call the cuda calculation
    // time
    auto start = std::chrono::steady_clock::now();
    interpolate(&gpuOutGrid, &inGrid, blockX, blockY, blockZ, interp_method); 


    auto end = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed_seconds = end-start;
    if (timing){ 
       std::cout << "GPU elapsed time: " << elapsed_seconds.count() << "s\n";
    }
    
    //print(gpuOutGrid, nxOut, nyOut, nzOut);

    //check output
    start = std::chrono::steady_clock::now();
    inGrid.interpolate(cpuOutGrid);
    end = std::chrono::steady_clock::now();
    elapsed_seconds = end-start;
    if (timing){ 
        std::cout << "CPU elapsed time: " << elapsed_seconds.count() << "s\n";
    }
    
    auto ierrors = ZPKG::volume::compare_output(&gpuOutGrid, &cpuOutGrid);
    
    // for debug
#if defined(VERBOSE)
    std::cout <<" ==== Input ====" << std::endl;
    inGrid.print();
    std::cout <<" ==== output from GPU ====" << std::endl;
    gpuOutGrid.print();
    std::cout <<" ==== output from CPU ====" << std::endl;
    cpuOutGrid.print();
#endif

    return ierrors;
}

#define _TEST_ACCURANCY_  1

int main(int argc, char* argv[]) 
{
   int blockX = 1;// 32;
   int blockY = 1;// 32;
   int blockZ = 1;// 32;

   //std::cout <<" input block size for the GPU:" << std::endl;
   //std::cin >> blockX >> blockY >> blockZ;
   int interp_method = 1;

   std::vector<std::tuple<int, int, int>> failed_tests;

   auto start = std::chrono::steady_clock::now();
#if _TEST_ACCURANCY_

   // test scale up:
   std::cout <<" Test scale up...\n";

   const int minX = 1;//1;// 101;
   const int minY = 1;//1;//101;
   const int minZ = 1;//1;// 101;

   const int maxX = 15;// 101;
   const int maxY = 15;//101;
   const int maxZ = 10;// 101;

   int nxOut = maxX; //1024; //scaleX;
   int nyOut = maxY; //234; //scaleY;
   int nzOut = maxZ; //173; //scaleZ;

   bool timing=false; 

   size_t total_tests = (maxX-minX-1) *(maxY-minY-1) * (maxZ-minZ-1);
   size_t iaccu = 0;
   size_t totalTestsRun = 0;
   for( int i = minX; i < maxX; i += 1) {
   for( int j = minY; j < maxY; j += 1) {
   for( int k = minZ; k < maxZ; k += 1) {
       iaccu++;
       int pcnt = iaccu*100/total_tests;
       if ( pcnt % 10 == 0) std::cout << pcnt <<"% done\r" << std::flush;

       for( int nxOut = i+1; nxOut < maxX; nxOut += 1) {
       for( int nyOut = i+1; nyOut < maxY; nyOut += 1) {
       for( int nzOut = i+1; nzOut < maxZ; nzOut += 1) {

          ++totalTestsRun;

          //std::cout << " running tests "<< iaccu <<" scale from ["<< i <<", " << j <<", " << k <<"] to [" << nxOut <<", " << nyOut <<", " << nzOut << "]\n";
          
          // test scale up from size[i, j, k] to [nxOut, nyOut, nzOut];
          auto irr = test(i, j, k, nxOut, nyOut, nzOut, blockX, blockY, blockZ, timing, interp_method);
          if( irr != 0 ) {
              failed_tests.push_back(std::make_tuple(i,j,k));
              std::cout <<" test failed from :[" << i <<", " << j <<", " << k <<"] to [" << nxOut <<", " << nyOut <<", " << nzOut << "]\n";
              std::cout <<" total errors: " << irr <<  std::endl; 
              exit(1);
              //goto next;
          }
       }
       }
       }

   }
   }
   }

next:

   auto check_results = [&failed_tests](std::string testname, std::string fname, int totalTestsRun) {
       if (failed_tests.size() != 0) {
           // sorry not work for tuples.
           //std::copy(failed_tests.begin(), failed_tests.end(), std::ostream_iterator<std::tuple<int, int, int>>(std::cout, "\n"));

           auto o = [&failed_tests](std::ostream & out) {
               for (auto&& tuple: failed_tests) {
                  int X, Y, Z;
                  std::tie(X, Y, Z) = tuple;
                  out << X << " " << Y << " " << Z << std::endl;
               }
           };

           if (failed_tests.size() < 300){
               o(std::cout);
           } else {
               std::ofstream of(fname);
               o(of);
               of.close();
           } 
           std::cout <<"==== Total "<< failed_tests.size() <<" "<< testname.c_str() <<" failed " <<" out of " << totalTestsRun <<" ====" << std::endl;
       } else {
         std::cout <<"==== ALL " << totalTestsRun <<" tests for "<< testname.c_str() <<" PASSED ====" << std::endl;
       }
   };

   check_results("scale up tests", "scale_up.failed.txt", totalTestsRun);

   // test scale down: 
   std::cout <<"\n Test scale down ...\n";
   {
       failed_tests.clear();
       iaccu = 0;
       totalTestsRun = 0;

       for( int i = maxX; i > minX; --i) {
       for( int j = maxY; j > minY; --j) {
       for( int k = maxZ; k > minZ; --k) {

          iaccu++;
          int pcnt = iaccu*100/total_tests;
          if ( pcnt % 10 == 0) std::cout << pcnt <<"% done\r" << std::flush;
          
          bool timing=false; 
          for( int nxOut = i; nxOut > 0; nxOut -= 1) {
          for( int nyOut = j; nyOut > 0; nyOut -= 1) {
          for( int nzOut = k; nzOut > 0; nzOut -= 1) {

              ++totalTestsRun;
          
              // test scale down from size[i, j, k] to [nxOut, nyOut, nzOut];
              auto irr = test(i, j, k, nxOut, nyOut, nzOut, blockX, blockY, blockZ, timing, interp_method);
              if( irr != 0 ) {
                  failed_tests.push_back(std::make_tuple(i,j,k));
                  std::cout <<" test failed from :[" << i <<", " << j <<", " << k <<"] to [" << nxOut <<", " << nyOut <<", " << nzOut << "]\n";
                  std::cout <<" total errors: " << irr <<  std::endl; 
                  exit(1);
                  //goto next;
              }
          }
          }
          }
       }
       }
       }
   }

   check_results("scale down tests","scale_down.failed.txt", totalTestsRun);

#else
   int nxIn = 1000;
   int nyIn = 1000;
   int nzIn = 1010; 
   int nxOut = 218;
   int nyOut = 531;
   int nzOut = 637;
   bool timing=true; 
  
   if(0 != test(nxIn, nyIn, nzIn, nxOut, nyOut, nzOut, blockX, blockY, blockZ, timing, interp_method)) {
      std::cout << "The test failed for from input: ["<< nxIn << ", " << nyIn << ", " << nzIn 
                << "] to [" <<nxOut <<", " << nyOut <<", " << nzOut <<"]." << std::endl;
   }

    nxIn = 1170; nyIn = 738; nzIn = 291;
    nxOut = 733, nyOut= 1179, nzOut= 1367;
    if(0 != test(nxIn, nyIn, nzIn, nxOut, nyOut, nzOut, blockX, blockY, blockZ, timing, interp_method)) { 
      std::cout << "The test failed for from input: ["<< nxIn << ", " << nyIn << ", " << nzIn 
                << "] to [" <<nxOut <<", " << nyOut <<", " << nzOut <<"]." << std::endl;
    }
/**
with 32 x 32 x 32 blocks or 32 x 32 x 16 block, similar results got:
GPU elapsed time: 0.551664s
CPU elapsed time: 3.69514s
GPU elapsed time: 0.198578s
CPU elapsed time: 51.3001s  // down takes much more time, this is suprise!!!
**/

#endif 

   auto end = std::chrono::steady_clock::now();
   std::chrono::duration<double> elapsed_seconds = end-start;
   std::cout << "TOTAL TIME elapsed for all tests: " << elapsed_seconds.count() << "s\n";

   return 0;
}


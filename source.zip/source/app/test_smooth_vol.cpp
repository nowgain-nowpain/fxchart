
#include "smoothfilter.h"
#include "volume.h"

#include <iostream>
#include <iomanip> 

#include <vector>
#include <tuple>
#include <iterator>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <chrono>

int test_smooth(int numX, int numY, int numZ, 
	int blockX, int blockY, int blockZ, bool timing) 
{
#if 1
    int halfx = 32; // half windows size in X direction.
    int halfy = 32; // half windows size in Y direction.
    int halfz = 33; // half windows size in Z direction.

    const size_t totalItems = numX*numY*numZ;
    ZPKG::volume inGrid(numX, numY, numZ); // input
    ZPKG::volume outGrid(numX, numY, numZ);  // output
    ZPKG::volume cpuOutGrid(numX, numY, numZ);  // output

    ZPKG::volume::fill_input_grid(inGrid);

    // call the cuda calculation
    // time
    auto start = std::chrono::steady_clock::now();
    average(outGrid.data(), inGrid.data(), halfx, halfy, halfz, numX, numY, numZ, blockX, blockY, blockZ); 

    auto end = std::chrono::steady_clock::now();
    std::chrono::duration<double> elapsed_seconds = end-start;
    if (timing){ 
       std::cout << "GPU elapsed time: " << elapsed_seconds.count() << "s\n";
    }

    //check output
    start = std::chrono::steady_clock::now();
    inGrid.cpu_average(&cpuOutGrid, halfx, halfy, halfz);
    end = std::chrono::steady_clock::now();
    elapsed_seconds = end-start;
    if (timing){ 
        std::cout << "CPU elapsed time: " << elapsed_seconds.count() << "s\n";
    }
    
    int ierrs = ZPKG::volume::compare_output(&outGrid, &cpuOutGrid);  
	return ierrs;
#else
		return 0;
#endif 
}

#define _TEST_ACCURANCY_  1 

int main(int argc, char* argv[]) 
{
   int blockX = 1;
   int blockY = 1;
   int blockZ = 1;
   std::cout <<" input block size for the GPU:" << std::endl;
   std::cin >> blockX >> blockY >> blockZ;

   auto start = std::chrono::steady_clock::now();

   std::vector<std::tuple<int, int, int>> failed_tests;
   bool timing = false;

#if _TEST_ACCURANCY_
   const int maxX = 15; //211; // 211/129/17 takes too long to finishes 2-3 hours! Don't run it.
   const int maxY = 37; //139;
   const int maxZ = 28;

   int iaccu = 0;
   for( int i = 3; i < maxX; ++i) {
   for( int j = 3; j < maxY; ++j) {
   for( int k = 3; k < maxZ; ++k) {
      if (0 == iaccu++ % 100) std::cout <<" === running test_smooth " << iaccu <<". smooth a volum of size (" << i <<", " << j <<", " << k <<") ===" << std::endl;
      if (0 != test_smooth(i, j, k, blockX, blockY, blockZ, timing)) failed_tests.push_back(std::make_tuple(i,j,k));
   }
   }
   }

   //std::cout <<" Running test_smooth 500, 328, 357" <<std::endl;
   //if (0 != test_smooth(500, 328, 357, blockX, blockY, blockZ, true)) failed_tests.push_back(std::make_tuple(500, 328, 357));

   if (failed_tests.size() != 0) {
       // sorry not work for tuples.
       //std::copy(failed_tests.begin(), failed_tests.end(), std::ostream_iterator<std::tuple<int, int, int>>(std::cout, "\n"));

       for (auto&& tuple: failed_tests) {
         int X, Y, Z;
         std::tie(X, Y, Z) = tuple;
         std::cout << X << " " << Y << " " << Z << std::endl;
      }

   } else {
     std::cout <<"==== ALL TESTS PASSED ====" << std::endl;
   }
#else
   //test_smooth(500, 828, 357, blockX, blockY, blockZ, true) ;
   int ierr = test_smooth(500, 800, 700, blockX, blockY, blockZ, true) ;
# endif 

   auto end = std::chrono::steady_clock::now();
   std::chrono::duration<double> elapsed_seconds = end-start;
   std::cout << "TOTAL TIME elapsed for all tests: " << elapsed_seconds.count() << "s\n";

   return 0;
}


#include "pined_memory.h"

int main()
{
  //Z: after some tests: on VWS Quadro M3000 SE, 
  // pined is ~5-10 faster than pageable when transfer smaller chunks,
  // e.g. 16MB, but when increase data to 1GB/2GB, the increase is 
  // ~1-2%. It is affected by the CPU and host machine bus. So need 
  // test for each machine configuration. 
  unsigned int nElements = 2* 256*1024*1024;
  const unsigned int bytes = nElements * sizeof(float);

  pageable_memory_transfer(bytes, nElements);
  pined_memory_transfer(bytes, nElements);
  return 0;
}


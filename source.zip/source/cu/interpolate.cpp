
#include "interpolate.h"
#include <volume.h>


extern "C"
void interpolate(ZPKG::volume* gridOut, ZPKG::volume const* gridIn, int blockX, int blockY, int blockZ, int interpMethod)
{
   switch (interpMethod) {
   case 0:
   default:
      interpNearPoint(gridOut, gridIn, blockX, blockY, blockZ);
      break;
   case 1:
      interpTrilinear(gridOut, gridIn, blockX, blockY, blockZ);
      break;
   }
}


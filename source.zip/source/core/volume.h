#ifndef _Z_VOLUME_H_
#define _Z_VOLUME_H_

#include "export_import.h"

namespace ZPKG {

class CORE_VOLUME_EXPORT  volume
{
public:
    volume(): storage_(nullptr), nx_(0), ny_(0), nz_(0) {}
    volume(unsigned int nx, unsigned int ny, unsigned int nz): nx_(nx), ny_(ny), nz_(nz), storage_(new float[nx_ * ny_* nz_]) {}
    virtual ~volume();

    float get_value(int iX, int iY, int iZ) const;
    void set_value(int iX, int iY, int iZ, float value);

    void cpu_average(volume* outGrid, int halfx, int halfy, int halfz) const;
     
    // TODO: refacctor: enum class, interpMethod=0: nearest, interpMethod=1: trilinear.
    void interpolate(volume& outGrid, int interpMethod=0) const;
    void interpNearPoint(volume& outGrid) const;
    void interpTriLinear(volume& outGrid) const;
    float iterpTriLinear(int i, int j, int k,  
       float myI, int floorI, int ceilI,  
       float myJ, int floorJ, int ceilJ,  
       float myK, int floorK, int ceilK) const;

    void interpTriCubic(volume& outGrid) const;


    int numX() const {return nx_;}
    int numY() const {return ny_;}
    int numZ() const {return nz_;}

    float* data() { return storage_; }
    void print() const;

    // static functions
    static int compare_output(volume const* outGrid, volume const* cpuOutGrid);

    // fill a volume with random values
    // 0, 01234... 
    // 1, 000..., 111..., 222..., 333..., ....
    // 2, random
    static void fill_input_grid(volume& inGrid, int dataPattern = 2);

private:
    //
    // this algorithm is naive, but it handles the null/nan cells too. 
    //
    void averge_cube(volume* outGrid, int i, int j, int k, int halfx, int halfy, int halfz) const;

private: 
  int nx_ = 0;
  int ny_ = 0;
  int nz_ = 0;
  float* storage_ = nullptr;
};

}

#endif

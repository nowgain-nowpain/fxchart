#pragma once
 
#ifndef CORE_VOLUME_EXPORT_H
#define CORE_VOLUME_EXPORT_H

#if defined(_WIN32)
#	if defined(CORE_VOLUME_STATIC)
#		define CORE_VOLUME_EXPORT
#	else
#		if defined(CORE_VOLUME_EXPORTS)
#			define CORE_VOLUME_EXPORT __declspec(dllexport)
#		else
#			define CORE_VOLUME_EXPORT __declspec(dllimport)
#		endif
#	endif
#else
#   define CORE_VOLUME_EXPORT
#endif

#endif  //CORE_VOLUME_EXPORT_H
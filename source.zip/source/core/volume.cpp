

#include "volume.h"

#include <cassert>
#include <iostream>
#include <iomanip> 

#include <vector>
#include <tuple>
#include <iterator>

#include <cstdio>

#include <cmath>
// round() /trunc()/floor()/ceil()
// nearest/ truncate/ floor / ceiling

/**
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <chrono>
**/


using namespace ZPKG;

volume::~volume() 
{
   delete[] storage_;
}

  // get (i, iY, iZ)
float volume::get_value(int iX, int iY, int iZ) const
{
   size_t indx = iX * ny_ * nz_ + iY * nz_ + iZ;
   return storage_[indx];
}

void volume::set_value(int iX, int iY, int iZ, float value)
{
   size_t indx = iX * ny_ * nz_ + iY * nz_ + iZ;
   //if (iX == 0 && iY == 1 && iZ == 0) printf("==CPU index: %d with n(%d,%d,%d)\n", indx, nx_, ny_, nz_);
   storage_[indx] = value;
}

//
// helper function: 
// this algorithm is naive, but it handles the null/nan cells too. 
//
void volume::averge_cube(volume* outGrid, int i, int j, int k, int halfx, int halfy, int halfz) const
{
   //assert(outGrid != nullptr);

   const float nullValue = 999; 
   
   // Need only half of filter length for all computations
   int xStart = i - halfx;
   int yStart = j - halfy;
   int zStart = k - halfz;
   
   int xEnd = i + halfx + 1;
   int yEnd = j + halfy + 1;
   int zEnd = k + halfz + 1;
   
   if(xStart < 0) xStart = 0;
   if(yStart < 0) yStart = 0;
   if(zStart < 0) zStart = 0;
   
   if(xEnd > nx_) xEnd = nx_;
   if(yEnd > ny_) yEnd = ny_;
   if(zEnd > nz_) zEnd = nz_;
   
   float value;
   float sum = 0.0;
   int   numValues = 0;
   
   for (auto iX = xStart; iX < xEnd; iX++) {
      for (auto iY = yStart; iY < yEnd; iY++) {
         for (auto iZ = zStart; iZ < zEnd; iZ++) {
            value = this->get_value(iX, iY, iZ);
            if(value != nullValue) {
                sum += value;
                numValues ++;
            }
         }
      }
   }
   
   float avgValue=0;
   if(numValues == 0) {
      avgValue = nullValue;
   }else{
      avgValue = sum / numValues;
   }

   outGrid->set_value(i, j, k, avgValue);
}   

void volume::cpu_average(volume* outGrid, int halfx, int halfy, int halfz) const
{
   // This makes the algorithm 10times faster than no openmp!
   // e.g test(500, 328, 357) half(1,1,1) with openmp: 17s, without openmp: 179 s.
   #pragma omp parallel for collapse (3)
   for (int i = 0; i < nx_; ++i) {
      for (int j = 0; j < ny_; ++j) {
         for (int k = 0; k < nz_; ++k) {
             averge_cube(outGrid, i, j, k, halfx, halfy, halfz);
         }
      }
   }
}

/*
The outgrid must be defined and nx, ny, nz != 0!
memory already allocated.
*/
void volume::interpolate(volume& outGrid, int interpMethod) const
{
   switch (interpMethod) {
   case 0:
   default:
      interpNearPoint(outGrid);
      break;
   case 1:
      interpTriLinear(outGrid);
      break;
   }
}

// take the nearest point
void volume::interpNearPoint(volume& outGrid) const
{
   //Z: scale factor must be (nin-1)/(nout-1), NOT (nin/nout)!!!
   float scaleX = (numX() == 1 || outGrid.numX() ==1) ? 0 : float(numX()-1)/(outGrid.numX()-1);
   float scaleY = (numY() == 1 || outGrid.numY() ==1) ? 0 : float(numY()-1)/(outGrid.numY()-1);
   float scaleZ = (numZ() == 1 || outGrid.numZ() ==1) ? 0 : float(numZ()-1)/(outGrid.numZ()-1);
   
#ifdef _DEBUG_PRINT_
   std::cout <<" CPU: Scale X/Y/Z:" << scaleX <<", " << scaleY <<", " << scaleZ << std::endl;
#endif
   
   for (int i = 0; i < outGrid.numX(); ++i) {
      for (int j = 0; j < outGrid.numY(); ++j) {
         for (int k = 0; k < outGrid.numZ(); ++k) {
             
             int iX = int(round(i*scaleX));
             int iY = int(round(j*scaleY));
             int iZ = int(round(k*scaleZ));

             // This check is NOT need, I think, it's added because of old logic for scale:
             // nin/nout.
             //iX = iX < nx_ ? iX : nx_ - 1;
             //iY = iY < ny_ ? iY : ny_ - 1;
             //iZ = iZ < nz_ ? iZ : nz_ - 1;
             auto value = get_value(iX, iY, iZ);
             outGrid.set_value(i, j, k, value); 

#ifdef _DEBUG_PRINT_
             // Debug print
             if (std::isnan(value) || value < -1.0e-30 || value > 1.e10) {
                if (std::isnan(value)) printf(" ==> CPU value is nan:");
                if (value < -1.0e-30) printf(" ==> CPU value is < -1.0e-30:");
                if (value>1.0e10) printf(" ==> CPU value is > 1.e10:");

                printf("==CPU: x/y/zout:[%d,%d,%d], x/y/zin:[%d,%d,%d]; value:%f; i*scaleX:%f; j*scaleY:%f; k*scaleZ:%f.\n",
                     i, j, k, int(round(i*scaleX)), int(round(j*scaleY)), int(round(k*scaleZ)), value, i*scaleX, j*scaleY, k*scaleZ);
 
                size_t indx = iX * ny_ * nz_ + iY * nz_ + iZ;
                printf(" ==CPU: nx/ny/nz: [%d, %d, %d], ix/iy/iz:[%d, %d, %d]; indx: %d; total:%d, value:%f\n\n", nx_, ny_, nz_, iX, iY, iZ, indx, nx_*ny_*nz_, storage_[indx]);
             }
#endif

         }
      }
   }
}

// 
// tri-linear  interpolation
// take the nearest 8 points, then do linear interpolation.
/**
 Bilinear interpolation considers the closest 2x2 neighborhood of known pixel values surrounding the unknown pixel.
 It then takes a weighted average of these 4 pixels to arrive at its final interpolated value. This results in much smoother looking images than nearest neighbor.

 when all known pixel distances are equal, so the interpolated value is simply their sum divided by four.
*/
void volume::interpTriLinear(volume& outGrid) const
{
 // need clearify for handling some edge cases:
 //  1) if happenly on an existing point, no interp needed!
 //  2) if happenly on vertical grid of exisiting points, take left side points (A,C)? or right side points (B, D)?
 //                  A         B
 //                  *----*----*
 //                       | 
 //                       x 
 //                       | 
 //                  *----*----*
 //                  C         D
 //  3) align on horizontal grid, similar to 2).
    
   //Z: scale factor must be (nin-1)/(nout-1), NOT (nin/nout)!!!
   float scaleX = (numX() == 1 || outGrid.numX() ==1) ? 0 : float(numX()-1)/(outGrid.numX()-1);
   float scaleY = (numY() == 1 || outGrid.numY() ==1) ? 0 : float(numY()-1)/(outGrid.numY()-1);
   float scaleZ = (numZ() == 1 || outGrid.numZ() ==1) ? 0 : float(numZ()-1)/(outGrid.numZ()-1);

   for (int i = 0; i < outGrid.numX(); ++i) {
      for (int j = 0; j < outGrid.numY(); ++j) {
         for (int k = 0; k < outGrid.numZ(); ++k) {

             // myI/J/K is my i/j/k map to original vol grid, so it can be fraction.
             // floorI/J/K is the index in the orignal grid of the floor.
             // ceilI/J/K is the index in the orignal grid of the ceiling.
             float myI = round(i * scaleX);
             int floorI = floor(myI);
             int  ceilI = ceil(myI);

             float myJ = round(j * scaleY);
             int floorJ = floor(myJ);
             int  ceilJ = ceil(myJ);

             float myK = round(k * scaleZ);
             int floorK = floor(myK);
             int  ceilK = ceil(myK);
             auto v = iterpTriLinear(i, j, k, myI, floorI, ceilI, myJ, floorJ, ceilJ, myK, floorK, ceilK);
              
             outGrid.set_value(i, j, k, v);
         }
      }
   }
}

float volume::iterpTriLinear(int i, int j, int k, 
    float myI, int floorI, int ceilI, 
    float myJ, int floorJ, int ceilJ, 
    float myK, int floorK, int ceilK) const
{
   //https://en.wikipedia.org/wiki/Trilinear_interpolation
   float c000 = get_value(floorI, floorJ, floorK);
   float c001 = get_value(floorI, floorJ, ceilK);
   float c010 = get_value(floorI, ceilJ,  floorK);
   float c100 = get_value(ceilI,  floorJ, floorK);
   float c101 = get_value(ceilI,  floorJ, ceilK);
   float c110 = get_value(ceilI,  ceilJ,  floorK);
   float c111 = get_value(ceilI,  ceilJ,  ceilK);
   float c011 = get_value(floorI, ceilJ,  ceilK);
   
   float xd = (ceilI == floorI) ? 0 : (myI - floorI) / (ceilI - floorI); // (x - x0)/(x1 - x0);
   float yd = (ceilJ == floorJ) ? 0 : (myJ - floorJ) / (ceilJ - floorJ); //(y - y0)/(y1 - y0);
   float zd = (ceilK == floorK) ? 0 : (myK - floorK) / (ceilK - floorK); //(z - z0)/(z1 - z0);

   float c00 = c000*(1 - xd) + c100 * xd;
   float c01 = c001*(1 - xd) + c101 * xd;
   float c10 = c010*(1 - xd) + c110 * xd;
   float c11 = c011*(1 - xd) + c111 * xd;
    
   float c0 = c00*(1 - yd) + c10 * yd;
   float c1 = c01*(1 - yd) + c11 * yd;

   float c = c0 * (1 - zd) + c1 * zd;
   return c;
}

/**
Bicubic goes one step beyond bilinear by considering the closest 4x4 neighborhood of known pixels — for a total of 16 pixels. Since these are at various distances from the unknown pixel, closer pixels are given a higher weighting in the calculation. Bicubic produces noticeably sharper images than the previous two methods, and is perhaps the ideal combination of processing time and output quality. For this reason it is a standard in many image editing programs (including Adobe Photoshop), printer drivers and in-camera interpolation.
**/
void volume::interpTriCubic(volume& outGrid) const
{
}

int volume::compare_output(volume const* outGrid, volume const* cpuOutGrid) 
{
   assert(outGrid != nullptr);

   int numX = outGrid->numX();
   int numY = outGrid->numY();
   int numZ = outGrid->numZ();
   if (cpuOutGrid->numX() != numX ||
       cpuOutGrid->numY() != numY ||
       cpuOutGrid->numZ() != numZ)  return false;

   int errs = 0;
   for (int i = 0; i < numX; ++i) {
      for (int j = 0; j < numY; ++j) {
         for (int k = 0; k < numZ; ++k) {
            auto value1 = outGrid->get_value(i, j, k);
            auto value2 = cpuOutGrid->get_value(i, j, k);

#ifdef _DEBUG_PRINT_
            // debug code
            if (value1 != value2 && ((value1 != 0 && fabs((value1-value2)/value1) > 1.0e-5) || 
                value1 == 0)) {
                ++errs;
                // float divid by 0, now gives inf in C++, no throw.
                std::cout << i <<", " << j <<", " << k <<" : " << value1 <<", " << value2 
                          <<" with abs err: " << fabs(value1-value2) 
                          <<", relative err:" << fabs(1 - value2/value1)*100 <<"%"<< std::endl;
            }
#endif

         }
      }
   }

#ifdef _DEBUG_PRINT_
   if (!errs) {
      std::cout <<" We got a match between GPU output and CPU output for nx*ny*nz:" <<numX <<" x " << numY <<" x " << numZ << std::endl;
   }
#endif

   return errs;
}


void volume::print() const
{
   std::cout <<" size of the volume: ["<< nx_ <<", " << ny_ <<", " << nz_ <<"]:" << std::endl;
   for (int i = 0; i < nx_; ++i) {
      std::cout << " X = " << i <<  std::endl; 
      std::cout <<"Z | Y ---> " << std::endl;
      for (int k = 0; k < nz_; ++k) {
         for (int j = 0; j < ny_; ++j) {
            auto value1 = get_value(i, j, k);
            if (0 == j) std::cout << k << "\t";
            std::cout <<  std::setprecision(5) << value1 <<"\t"; 
         }
         std::cout  << std::endl; 
      }
      std::cout  << std::endl; 
   }

   /*
   std::cout <<" print again in order:\n";
   for (int idx = 0; idx < nx_ * ny_ * nz_; ++idx) {
        std::cout << std::setprecision(5) << storage_[idx] <<"\t";
        if ((idx+1) % 6 == 0) std::cout << std::endl;
   }
   std::cout  << std::endl; 
   */
}

#define _RANDOM_NUMBER_ 1
void volume::fill_input_grid(volume& inGrid, int dataPattern) 
{
    // init the vol 
    switch (dataPattern) {
    case 1: 
        std::srand(std::time(nullptr)); // use current time as seed for random generator
        for (int i = 0; i < inGrid.numX(); ++i) {
            size_t area = inGrid.numY() * inGrid.numZ();
            for (int j = 0; j < area; ++j) {
               int random_variable = std::rand();
               inGrid.data()[j+i*area] = random_variable;
            }       
        }

        break;
    case 2:
        // user patterned number: 0000 1111 2222 3333
        for (int i = 0; i < inGrid.numX(); ++i) {
            size_t area = inGrid.numY() * inGrid.numZ(); 
            for (int j = 0; j < area; ++j) {
               inGrid.data()[j+i*area] = i;
            }       
        }

        break;

    default:
    case 0:
        // 0, 1, 2, 3 ...., (nx*ny*nz-1)
        for (int i = 0; i < inGrid.numX() *inGrid.numY() * inGrid.numZ(); ++i) {
            inGrid.data()[i] = i;
        }
    }
}

